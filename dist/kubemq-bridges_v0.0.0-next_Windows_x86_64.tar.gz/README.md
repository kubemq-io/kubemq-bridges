# kubemq-bridges




## Concept

![concept](.github/assets/concept.jpeg)


### Bridge

![bridge](.github/assets/bridge.jpeg)

### Replicate

![replicate](.github/assets/replicate.jpeg)

### Aggregate

![aggregate](.github/assets/aggregate.jpeg)

### Transform

![transform](.github/assets/transform.jpeg)

## Installation


## Configuration


